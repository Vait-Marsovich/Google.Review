import SwiftUI
import WebKit
import Network

struct ContentView: View {
  var body: some View {
    WebView().edgesIgnoringSafeArea(.all)
  }
}

struct WebView: UIViewRepresentable {
  func makeUIView(context: Context) -> WKWebView {
    let webView = WKWebView()
    webView.scrollView.isScrollEnabled = true
//    webView.javaScriptEnabled = true
    return webView
  }

  func updateUIView(_ webView: WKWebView, context: Context) {
    let liveView = "https://maxivimax.github.io/newPtzGO/run.html" //
    if let url = URL(string: liveView) {
       let request = URLRequest(url: url)
       webView.load(request)
    }
  }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
  static var previews: some View {
    ContentView()
  }
}
#endif
